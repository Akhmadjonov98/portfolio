const sr = ScrollReveal({
    origin: 'top',
    distance: '120px',
    duration: 3000,
    reset: true


})
// sr.reveal('.head_App', {})
// sr.reveal('.head_text', { delay:100})
// sr.reveal('.trus', { delay:100})
// sr.reveal('.sped', { delay:200})
// sr.reveal('.three_like', { delay:200})
// sr.reveal('.sma', {delay:100})
// sr.reveal('.why', { delay:100})
// sr.reveal('.why_p', {delay:200})
// sr.reveal('.bot1', { delay:100})
// sr.reveal('.bot2', {delay:200})
// sr.reveal('.head_title', {delay:200})
// sr.reveal('.ultimate', { delay:200})
// sr.reveal('.ultimate_p', {delay:100})

// sr.reveal('.head_button', {interval:100})
// sr.reveal('.ulti1', {interval:100})
// sr.reveal('.ulti2', { delay:100})
// sr.reveal('.get', { delay:200})
// sr.reveal('.get_p', { delay:100})
// sr.reveal('.knopka', { delay:100})
// sr.reveal('.dollor', { delay:100})
// sr.reveal('.ask_01', { delay:200})
// sr.reveal('.ask_02', { delay:100})
// sr.reveal('.asked3', { delay:100})
// ask_01 sr.reveal('.layer', {delay:400})



const sd = ScrollReveal({
    origin: 'left',
    distance: '220px',
    duration: 3000,
    reset: true
})
sd.reveal('.layer', { delay:100})
sd.reveal('.copy_phone', { delay:100})
sd.reveal('.map1', { delay:200})
// sd.reveal('.botom_ap', { delay:100})
// sd.reveal('.seeall', { delay:200})







const sa = ScrollReveal({
    origin: 'right',
    distance: '220px',
    duration: 3000,
    reset: true


})

sa.reveal('.phone', { delay:200})
sa.reveal('.copy_phone', { delay:200})
sa.reveal('.phone4', { delay:200})
// sa.reveal('.more', { delay:400})
// sa.reveal('.map2', { delay:200})
sa.reveal('.city', { delay:200})
